Instructions
------------

Start CSV data generation by typing 'mvn benerator:generate' on the command line.
If you need to use another logging framework, change the 'pom.xml's dependency to slf4j-log4j12 and log4j.