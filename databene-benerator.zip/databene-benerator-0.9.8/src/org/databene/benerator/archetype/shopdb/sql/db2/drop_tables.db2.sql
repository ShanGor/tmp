DROP TABLE db_order_item;
DROP TABLE db_order;
DROP TABLE db_customer;
DROP TABLE db_user;
DROP TABLE db_role;
DROP TABLE db_product;
DROP TABLE db_category;
DROP SEQUENCE seq_id_gen;
