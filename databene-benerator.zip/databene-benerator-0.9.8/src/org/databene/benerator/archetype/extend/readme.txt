Instructions
------------

Start data generation by typing 'mvn compile benerator:generate' on the command line.
Find sample implementations of the Benerator extension interfaces at src/main/java.
If you need to use another logging framework, change the 'pom.xml's dependency to slf4j-log4j12 and log4j.